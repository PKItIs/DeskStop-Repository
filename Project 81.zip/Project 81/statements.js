canvas =document.getElementById("mycanva")
ref = canvas.getContext("2d")

ref.beginPath()
ref.strokeStyle = "blue"
ref.lineWidth = 5
ref.arc(200, 210, 40, 0, 2 * Math.PI)
ref.stroke()

ref.beginPath()
ref.strokeStyle = "black"
ref.lineWidth = 5
ref.arc(250, 210, 40, 0, 2 * Math.PI)
ref.stroke()

ref.beginPath()
ref.strokeStyle = "red"
ref.lineWidth = 5
ref.arc(300, 210, 40, 0, 2 * Math.PI)
ref.stroke()

ref.beginPath()
ref.strokeStyle = "yellow"
ref.lineWidth = 5
ref.arc(225, 250, 40, 0, 2 * Math.PI)
ref.stroke()

ref.beginPath()
ref.strokeStyle = "green"
ref.lineWidth = 5
ref.arc(275, 250, 40, 0, 2 * Math.PI)
ref.stroke()